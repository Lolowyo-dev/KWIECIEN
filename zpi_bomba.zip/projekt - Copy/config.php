<?php

$config = [
    'db' => [
        'host' => "localhost",
        'user' => "root",
        'pass' => "",
        'name' => "komunikator",
        'handle' => null,
    ],
    'proto' => "http",
    'url' => "localhost/projekt",
    'title' => "Komunikator online",
    'template' => "default",
    'default_page' => "/Web/Auth",
    'css' => [],
    'js' => [],
];