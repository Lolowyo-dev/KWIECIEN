<?php

namespace Model;

class Friendship
{
    private $conn;
    private $table = 'friendships';

    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function sendRequest($user1_id, $user2_id)
    {
        $query = "INSERT INTO {$this->table} (user1_id, user2_id, status) VALUES (:user1_id, :user2_id, 'pending')";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user1_id', $user1_id);
        $stmt->bindParam(':user2_id', $user2_id);

        return $stmt->execute();
    }

    public function updateStatus($request_id, $status)
    {
        $query = "UPDATE {$this->table} SET status = :status WHERE id = :request_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':request_id', $request_id);

        return $stmt->execute();
    }

    public function getAcceptedFriends($user_id)
    {
        $query = "SELECT users.id, users.username 
                FROM friendships 
                JOIN users ON (users.id = friendships.user1_id OR users.id = friendships.user2_id)
                WHERE (friendships.user1_id = :user_id OR friendships.user2_id = :user_id)
                  AND friendships.status = 'accepted'
                  AND users.id != :user_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
}
