<?php

namespace Model;

use PDO;

class Status
{
    private $conn;
    private $table = 'message_status';

    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function updateStatus($message_id, $user_id, $status)
    {
        $query = "UPDATE {$this->table} SET status = :status WHERE message_id = :message_id AND user_id = :user_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':message_id', $message_id);
        $stmt->bindParam(':user_id', $user_id);

        return $stmt->execute();
    }

    public function getStatus($message_id, $user_id)
    {
        $query = "SELECT status FROM {$this->table} WHERE message_id = :message_id AND user_id = :user_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':message_id', $message_id);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function updateMessageStatus($message_id, $user_id)
    {
        // First, we check if the status is 'unread'
        $currentStatus = $this->getStatus($message_id, $user_id);

        if ($currentStatus && $currentStatus['status'] == 'unread') {
            // Update the message status to 'read'
            return $this->updateStatus($message_id, $user_id, 'read');
        }

        return false; // If the message is already read, we don't update it
    }
}
