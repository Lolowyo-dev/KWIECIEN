<?php

namespace Web;

class Chat extends \Application\Main
{
    public function __construct($cmd, $config)
    {
        parent::__construct($cmd, $config);
    }

    public function show()
    {
        if (!isset($_SESSION['user'])) {
            $Controller = $this->GetInstance('Application\Controller');
            $Controller->redirectPage("/Web/Auth", true);
        }

        // Add assets (CSS, JS)
        $this->addAsset("chat.css", "css");
        $this->addAsset("chat.js", "js");

        $DataBase = $this->GetInstance('Drivers\DataBase');
        $Controller = $this->GetInstance('Application\Controller');
        $User = $this->GetInstance('Model\User');
        $Friendship = $this->GetInstance('Model\Friendship');
        $Message = $this->GetInstance('Model\Message');
        $Status = $this->GetInstance('Model\Status');

        $db = $DataBase->dbConnect();

        // Assuming the contact's ID is available, e.g., from URL or session
        // $contact_id = $_GET['contact_id']; // Or any other way to get contact ID
        $contact_id = 9; // Hardcoded for testing
        $user_id = $_SESSION['user']['id'];

        // Fetch messages
        $messages = $Message->getMessages($user_id, $contact_id);

        // // Update message status to 'read' for all the messages in the chat
        // foreach ($messages as $message) {
        //     $Status->updateMessageStatus($message['message_id'], $user_id); // Mark as read
        // }

        // Load templates
        $templates = ["header.php", "chat.php", "footer.php"];
        foreach ($templates as $template) {
            $path = $this->getTemplatePath($template);
            if ($path) {
                include $path;
            }
        }
    }
}
