<?php


namespace API;

require_once '../Application/Main.php';

class MessageStatusHandle extends \Application\Main
{
    public function __construct($cmd, $config)
    {
        parent::__construct($cmd, $config);
    }

    public function updateMessageStatus($message_id, $user_id, $status)
    {
        $Status = $this->GetInstance('Model\Status');

        // Update the message status
        return $Status->updateStatus($message_id, $user_id, $status);
    }
}

// Example of how you might call the methods
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $message_id = $data['message_id'];
    $user_id = $data['user_id'];

    // Instantiate the class and update the message status
    $messageHandler = new MessageStatusHandle();
    $statusUpdated = $messageHandler->updateMessageStatus($message_id, $user_id, 'read');

    // Handle success or failure
    if ($statusUpdated) {
        // Return success response
        echo json_encode(['success' => true]);
    } else {
        // Return failure response
        echo json_encode(['success' => false]);
    }
}
