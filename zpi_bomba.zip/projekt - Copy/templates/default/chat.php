<aside>
    <div class="friend-list-toggle">
    </div>
    <div class="friend-list">
        <?php include("templates/default/components/friends.php"); ?>
    </div>
</aside>
<main>
    <nav>
        <div class="nav-wrapper">
            <div class="nav-left">
                <div class="chat-icon">
                    <img src="/projekt/templates/default/gfx/profile.png" alt="profile">
                </div>
                <div class="chat-name">
                    <span>Chat z kims tam</span>
                </div>
            </div>
            <div class="nav-right">

                <div class="search">
                    <div class="search-input">
                        <input type="text" placeholder="Szukaj">
                    </div>
                    <div class="search-button">
                        <button>
                            <img src="/projekt/templates/default/gfx/search.png" alt="search">
                        </button>
                    </div>

                </div>
                <div class="profile">
                    <img src="/projekt/templates/default/gfx/profile.png" alt="profile">
                </div>
            </div>
        </div>
    </nav>
    <div class="messages">
        <?php include("templates/default/components/messages.php"); ?>

    </div>
    <div class="chat-container">
        <form class="message-form" method="post">
            <div class="message-input-container">
                <textarea id="messageInput" name="message" placeholder="Napisz wiadomość..." rows="1"></textarea>
                <button type="submit" id="sendButton">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                        <path fill="currentColor" d="M3 21v-7l15-2-15-2v-7l21 9z" />
                    </svg>
                </button>
            </div>
        </form>
    </div>

</main>