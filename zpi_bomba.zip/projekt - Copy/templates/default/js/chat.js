document.addEventListener("DOMContentLoaded", () => {
  const messageInput = document.getElementById("messageInput");

  if (messageInput) {
    messageInput.addEventListener("input", function () {
      this.style.height = "auto";

      const newHeight = Math.min(this.scrollHeight, 150);
      this.style.height = `${newHeight}px`;
    });
  }
});
