<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $this->config['title'] ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <?= $this->loadAssets() ?>
    <link rel="stylesheet" href="/projekt/templates/default/css/style.css">
    <link rel="stylesheet" href="/projekt/templates/default/css/tailwind.css">
</head>

<body>
    <div class="content">