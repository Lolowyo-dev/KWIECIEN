<!-- <div class="message sent">
        <span class="message-content">this is message that i sent</span>
        <span class="status">read</span>
</div>

<div class="message">
        <span class='user'>friend 1</span>
        <span class="message-content">this is message that i recived</span>
        <span class="status">read</span>
</div>

<div class="message">
        <span class='user'>friend 1</span>
        <span class="message-content">random message 1</span>
        <span class="status">read</span>
</div>

<div class="message sent">
        <span class="message-content">random message 2</span>
        <span class="status">unread</span>
</div> -->

<?php
// Loop through the messages from the database (as fetched by your backend)
foreach ($messages as $message) {
        // Check if the logged-in user is the sender or receiver
        $message_id = $message['message_id'];
        $isSent = ($message['sender_id'] == $user_id);
        $contact = ($isSent) ? $User->findById($message['receiver_id']) : $User->findById($message['sender_id']);
        $status = $message['message_status'] ? $message['message_status'] : 'unread'; // Default to 'unread' if no status is found
?>
        <div class="message <?php echo htmlspecialchars($isSent ? 'sent' : ''); ?>"
                id="m_id_<?php echo htmlspecialchars($message_id); ?>" data-status="<?php echo htmlspecialchars($status); ?>"
                data-message-id="<?php echo htmlspecialchars($message_id); ?>"
                data-user-id="<?php echo htmlspecialchars($contact['id']); ?>">
                <?php if (!$isSent) { ?>
                        <span class="user"><?php echo htmlspecialchars($contact['username']); ?></span>
                <?php } ?>
                <span class="message-content"><?php echo htmlspecialchars($message['message_content']); ?></span>
                <span class="status"><?php echo $status; ?></span>
        </div>
<?php
}
?>

<script>
        document.addEventListener('DOMContentLoaded', function() {
                // Pass user_id from PHP to JavaScript (available in $_SESSION['user']['id'])
                const userId = <?php echo $_SESSION['user']['id']; ?>;

                // Function to mark a message as 'read'
                function markMessageAsRead(messageId, userId) {
                        // Send AJAX request to update message status
                        fetch('../classes/API/MessageStatusHandle.php', { // Adjust path to match your route
                                        method: 'POST',
                                        headers: {
                                                'Content-Type': 'application/json',
                                        },
                                        body: JSON.stringify({
                                                message_id: messageId,
                                                user_id: userId,
                                        }),
                                })
                                .then(response => response.json())
                                .then(data => {
                                        console.log(data); // Log the response for debugging
                                        // Optionally update the status in the UI, e.g., change the status text
                                        if (data.success) {
                                                const messageElement = document.querySelector(`[data-message-id="${messageId}"]`);
                                                if (messageElement) {
                                                        messageElement.querySelector('.status').innerText = 'read';
                                                        messageElement.classList.remove('unread');
                                                        messageElement.classList.add('read');
                                                }
                                        }
                                })
                                .catch(error => {
                                        console.error('Error marking message as read:', error);
                                });
                }

                // IntersectionObserver to detect when the message is visible on the screen
                const observer = new IntersectionObserver((entries, observer) => {
                        entries.forEach(entry => {
                                if (entry.isIntersecting) {
                                        const messageElement = entry.target;
                                        const messageId = messageElement.getAttribute('data-message-id');
                                        const messageStatus = messageElement.getAttribute('data-status');

                                        // If the message is unread, mark it as read
                                        if (messageStatus === 'unread') {
                                                markMessageAsRead(messageId, userId);
                                        }

                                        // Once the message is read, stop observing it
                                        observer.unobserve(entry.target);
                                }
                        });
                }, {
                        threshold: 0.5 // Trigger when 50% of the message is in the viewport
                });

                // Start observing all message elements
                const messageElements = document.querySelectorAll('.message');
                messageElements.forEach(messageElement => {
                        observer.observe(messageElement);
                });
        });
</script>